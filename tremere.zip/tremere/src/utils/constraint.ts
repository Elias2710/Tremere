export class Constraint {
  static REQUEST_FEE = 15
}
